
public class HiloDecrementa extends Thread {

	Contador cont;
	
	public HiloDecrementa(Contador parametroCont) {
		this.cont = parametroCont;
	}

	@Override
	public void run() {
		for (int i = 0; i<300 ; i++){
			cont.decrementar();
		}
	}
}
