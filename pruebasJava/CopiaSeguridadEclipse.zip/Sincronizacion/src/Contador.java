public class Contador {

	private int c;
	
	public Contador(int c) {
		this.c = c;
	}
	
	public synchronized void incrementar(){
		c++;
	}
	
	public void decrementar(){
		
		synchronized(this){
			c--;	
		}
	}

	@Override
	public String toString() {
		return "["+ c +"]";
	}


	
	
	
}
