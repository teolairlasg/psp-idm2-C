
public class Programa {

	public static void main(String[] args) throws InterruptedException {
	
		Contador contador = new Contador(0);
		
		HiloIncrementa hi = new HiloIncrementa(contador);
		HiloDecrementa hd = new HiloDecrementa(contador);
		
		hi.start();
		hd.start();
		
		Thread.sleep(500);
		System.out.println(contador);

	}

}
