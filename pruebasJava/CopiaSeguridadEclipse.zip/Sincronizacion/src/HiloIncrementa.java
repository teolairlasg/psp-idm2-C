
public class HiloIncrementa extends Thread {
	
	Contador cont;
	
	public HiloIncrementa(Contador parametroCont) {
		this.cont = parametroCont;
	}

	@Override
	public void run() {
		for (int i = 0; i<300 ; i++){
			cont.incrementar();
		}
	}
	
	

}
