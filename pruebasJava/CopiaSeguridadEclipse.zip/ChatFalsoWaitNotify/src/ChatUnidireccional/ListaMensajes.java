package ChatUnidireccional;

import java.util.ArrayList;
import java.util.List;

public class ListaMensajes {

	private static List<Mensaje> mensajesNuevos;

	public ListaMensajes(){
		mensajesNuevos = new ArrayList<Mensaje>();
	}
	
	public synchronized Mensaje obtenerMensaje(){
		if (mensajesNuevos.size()==0){
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Mensaje m = mensajesNuevos.get(0);
		mensajesNuevos.remove(0);
		return m;	
	}	
	
	public synchronized void enviarMensaje(Mensaje m){
		mensajesNuevos.add(m);
		this.notify();
	}
}
