package ChatUnidireccional;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class RecibireImprimir extends Thread {

	private ListaMensajes mensajes;
	private Integer mensajesImprimidos;

	public RecibireImprimir(ListaMensajes mensajes) {
		this.mensajes = mensajes;
		mensajesImprimidos = 0;
	}
	
	private void ejecutarComando(Mensaje mensaje) {
		if (mensaje.getContenido().equals("#date")){
			Date fecha = new Date();
			System.out.println(fecha);
		}else if (mensaje.getContenido().equals("#quit")){
			Chat.finalizarPrograma();
		}else{
			System.out.println("Comando '"+mensaje.getContenido()+"' desconocido");
		}	
	}

	private boolean esUnComando(Mensaje mensaje) {
		return mensaje.getContenido().startsWith("#");
	}

	@Override
	public void run() {
		while(!Chat.finalPrograma()){
			Mensaje m = mensajes.obtenerMensaje();
			if(esUnComando(m)){
				ejecutarComando(m);
			}else{
				System.out.println(m);
			}
		}
	}
}
