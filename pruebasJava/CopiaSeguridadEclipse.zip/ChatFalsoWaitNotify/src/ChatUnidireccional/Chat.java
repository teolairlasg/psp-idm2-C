package ChatUnidireccional;

import java.util.ArrayList;
import java.util.List;

public class Chat {

	
	private static boolean finalPrograma = false;
	
	static void finalizarPrograma(){
		finalPrograma = true;
	}
	
	static boolean finalPrograma(){
		return finalPrograma;
	}
	
	public static void main(String[] args) {
		ListaMensajes mensajes = new ListaMensajes();

		LeeryEnviar emisor = new LeeryEnviar(mensajes);
		RecibireImprimir receptor = new RecibireImprimir(mensajes);
		
		receptor.start();
		emisor.start();
	}

}
