package ChatUnidireccional;

import java.util.List;
import java.util.Scanner;

public class LeeryEnviar extends Thread {

	private ListaMensajes mensajes;
	
	Scanner teclado = new Scanner(System.in);

	public LeeryEnviar(ListaMensajes mensajes) {
		this.mensajes = mensajes;
	}
	@Override
	public void run() {
		String linea = null;
		while(!Chat.finalPrograma()){
			linea = teclado.nextLine();
			Mensaje m = new Mensaje(linea);
			mensajes.enviarMensaje(m);
		}
	}
}


