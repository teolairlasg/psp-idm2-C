import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;


public class TraductorPalabra {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		Scanner teclado = new Scanner (System.in);
		System.out.println("Escriba la palabra a buscar:\n");
		String palabra = teclado.nextLine();
		teclado.close();
		
		//URL url =  new URL("http://www.wordreference.com/enes/"+palabra);
		URL url2 =  new URL("http://httpbin.org/post");

		
		URLConnection urlconn = url2.openConnection();
		urlconn.setDoOutput(true); //Esta conexion acepta peticiones
		
		PrintWriter salida = new PrintWriter(urlconn.getOutputStream());
		salida.write("spen="+palabra+"&var=valor");
		salida.close();
		
		/*BufferedReader br = new BufferedReader(
				new InputStreamReader(url.openStream()));*/
		BufferedReader br2 = new BufferedReader(
				new InputStreamReader(urlconn.getInputStream()));
		String linea;
		while ( (linea=br2.readLine()) != null){
			System.out.println(linea);
		}
		/*
		while ( (linea=br2.readLine()) != null){
			if(linea.contains("<td class='ToWrd' >")){
				int posInicial = linea.indexOf("<td class='ToWrd' >");
				linea = linea.substring(posInicial);
				int posFinal = linea.indexOf("</td>");
				linea=linea.substring(0, posFinal);
				
				while ( (posInicial = linea.indexOf("<")) != -1){
					posFinal = linea.indexOf(">");
					String parteInicial, parteFinal;
					if(posInicial == 0){
						parteInicial = "";
					}else{
						parteInicial = linea.substring(0,posInicial);
					}
					if(posFinal == linea.length()){
						parteFinal = "";
					}else{
						parteFinal = linea.substring(posFinal+1,linea.length());
					}
					linea = parteInicial + parteFinal;
				}
				System.out.println(linea);
			}
		}
		*/
	}
}
