import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;


public class PrimerosPasos {
	
	public static void main(String args[]) throws IOException{
		InetAddress direccion = null;
		InetAddress[] direcciones = null;
		try {
			direccion = InetAddress.getLocalHost();
			direcciones = InetAddress.getAllByName("www.google.es");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(direccion);
		System.out.println(direccion.getAddress());
		System.out.println(direccion.getHostAddress());
		System.out.println(direccion.getHostName());
		
		for(int i = 0; i< direcciones.length;i++){
			System.out.println(direcciones[i]);
		}
		URL url = null;
		try {
			url =new URL(
			"http://www.iessierradeguara.com/wordpress");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(url.getPort());
		System.out.println(url.getPath());
		System.out.println(url.getFile());
		System.out.println(url.getQuery());
		URLConnection conexion = null;
		
		try {
			conexion = url.openConnection();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader in_buf =
				new BufferedReader(
						new InputStreamReader(conexion.getInputStream()));
		String linea;
		while((linea = in_buf.readLine()) != null){
			System.out.println(linea);
		}
		
		
	}
		;

}
