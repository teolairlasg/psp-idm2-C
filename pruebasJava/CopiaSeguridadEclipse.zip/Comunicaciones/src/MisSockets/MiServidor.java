package MisSockets;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MiServidor {

	public static int PUERTO = 8123;
	
	public static void main(String[] args) throws IOException {
	
		ServerSocket serSock = new ServerSocket(PUERTO);
		
		System.out.println("A la espera de una conexión por el puerto "+PUERTO);
		Socket sock = serSock.accept();
		serSock.close();
		System.out.println("Cliente conectado...");
		System.out.println("Info cliente: \n--------\n"+sock.getInetAddress()+":"+sock.getPort());
		System.out.println("\n Mi info: \n---------\n"+sock.getLocalAddress()+":"+sock.getLocalPort());
		
		DataInputStream dis = new DataInputStream(sock.getInputStream());
		DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
		
		String leido = dis.readUTF();
		dos.writeUTF("Hola cliente!!");
		System.out.println("Cliente: "+leido );
		
		System.out.println("Cerrando conexion con el cliente");
		sock.close();

	}

}
