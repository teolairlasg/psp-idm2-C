package MisSockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MiCliente {

	public static int PUERTO = 8123;
	
	public static void main(String[] args) throws UnknownHostException, IOException {

		System.out.println("Conectando con el servidor localhost por el puerto "+PUERTO);
		Socket sock = new Socket("192.168.137.101", PUERTO);
		System.out.println("Conectado con "+sock.getInetAddress());
		
		DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
		DataInputStream dis = new DataInputStream(sock.getInputStream());
		
		String leido = dis.readUTF();
		dos.writeUTF("Hola Servidor, Luis, soy cliente");
		System.out.println("servidor: "+leido);
		
		
		
		sock.close();
		
	}

}
