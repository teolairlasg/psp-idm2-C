package ChatUnidireccional;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class RecibireImprimir extends Thread {

	private List<Mensaje> mensajes;
	private Integer mensajesImprimidos;

	public RecibireImprimir(List<Mensaje> mensajes) {
		this.mensajes = mensajes;
		mensajesImprimidos = 0;
	}
	
	public boolean hayMensajesNuevos(){
		if(mensajesImprimidos<mensajes.size()){
			return true;
		}else{
			return false;
		}
	}

	private void imprimirNuevosMensajes() {
		for(int i = 0; i<mensajes.size();i++){
			if(i>=mensajesImprimidos){
				if(esUnComando(mensajes.get(i))){
					ejecutarComandos(mensajes.get(i));
				}else{
					System.out.println(mensajes.get(i).toString());
				}
				mensajesImprimidos++;
			}
		}
	}
	
	private void ejecutarComandos(Mensaje mensaje) {
		if (mensaje.getContenido().equals("#date")){
			Date fecha = new Date();
			System.out.println(fecha);
		}else if (mensaje.getContenido().equals("#quit")){
			Chat.finalizarPrograma();
		}else{
			System.out.println("Comando '"+mensaje.getContenido()+"' desconocido");
		}	
	}

	private boolean esUnComando(Mensaje mensaje) {
		return mensaje.getContenido().startsWith("#");
	}

	@Override
	public void run() {
		while(!Chat.finalPrograma()){
			if(hayMensajesNuevos()){
				imprimirNuevosMensajes();
			}else{
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
