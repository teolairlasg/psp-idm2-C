package ChatUnidireccional;

public class Mensaje {

	private String contenido;

	@Override
	public String toString() {
		return "Mensaje:" + contenido + "\n";
	}

	public Mensaje(String contenido) {
		super();
		this.contenido = contenido;
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}
}
