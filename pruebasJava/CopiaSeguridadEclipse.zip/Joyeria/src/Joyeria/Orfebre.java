package Joyeria;

import java.util.Date;

public class Orfebre extends Thread {
	
	AlmacenOro almacen;
	
	public Orfebre(AlmacenOro almacen){
		this.almacen = almacen;
	}

	@Override
	public void run() {

		while(!ProgramaPrincipal.finalPrograma()){
			almacen.obtenerOro();		
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			System.out.println("Joya producida: "+(new Date()).toString());
		}
		
	}
	
	

}
