package Joyeria;

public class ProgramaPrincipal {

	public static boolean finalPrograma=false;
	
	public static boolean finalPrograma() {
		return finalPrograma;
	}
	
	public static void main(String[] args) throws InterruptedException{
		
			AlmacenOro almacen = new AlmacenOro();
			Minero minero1 = new Minero(almacen);
			Minero minero2 = new Minero(almacen);
			Orfebre orfebre1 = new Orfebre(almacen);
			
			orfebre1.start();
			Thread.sleep(1000);
			almacen.almacenarOro();
			almacen.almacenarOro();
			
			
			
			
	
			
	}

	private static void finalizarPrograma() {
		finalPrograma =true;
		
	}
	

}
