package Joyeria;

import java.util.Date;

public class Minero extends Thread {

	AlmacenOro almacen;
	
	public Minero(AlmacenOro almacen){
		this.almacen = almacen;
	}
	
	@Override
	public void run() {
		
		while(!ProgramaPrincipal.finalPrograma()){
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Pieza de oro extraída: "+(new Date()).toString());
			almacen.almacenarOro();
		}
	}
}
