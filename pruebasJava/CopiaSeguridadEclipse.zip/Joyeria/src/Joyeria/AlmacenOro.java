package Joyeria;

public class AlmacenOro {
	
	public AlmacenOro(){
		
	}
	
	public synchronized void obtenerOro(){
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public synchronized void almacenarOro(){
		notify();
	}
	
}
