import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class SocketPantalla extends Thread {

	InputStream in;
	private boolean hiloActivo;
	
	public SocketPantalla(InputStream in) {
		super();
		this.in = in;
		hiloActivo = true;
	}

	@Override
	public void run() {
		DataInputStream socketInput= new DataInputStream(in);
		
		String leido = null;
		
		while (hiloActivo){
			try {
				leido = socketInput.readUTF();
			} catch (IOException e) {
				System.err.println("Error leyendo del socket");
				e.printStackTrace();
			}
			System.out.println("Remoto: "+leido);
		}
	}

	public void finalizarHilo() {
		hiloActivo = false;
	}
	
}
