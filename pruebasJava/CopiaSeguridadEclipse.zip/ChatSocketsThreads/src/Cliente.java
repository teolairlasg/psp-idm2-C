import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;


public class Cliente {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Socket socket = null;
		try {
			socket = new Socket("localhost", Servidor.PUERTO);
		} catch (UnknownHostException e) {
			System.err.println("Error, servidor no encontrado");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Error, de E/S");
			e.printStackTrace();
		}

		System.out.println("Cliente: Conectado con "+socket.getInetAddress());

		TecladoSocket hiloEnvio = null;
		try {
			hiloEnvio = new TecladoSocket(socket.getOutputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		SocketPantalla hiloRecepcion = null;
		try {
			hiloRecepcion = new SocketPantalla(socket.getInputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		hiloEnvio.start();
		hiloRecepcion.start();
		
		try {
			Thread.sleep(100000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		hiloEnvio.finalizarHilo();
		hiloRecepcion.finalizarHilo();
		
		try {
			socket.close();
		} catch (IOException e) {
			System.err.println("Error cerrando el socket");
			e.printStackTrace();
		}
	}
}
