import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;


public class TecladoSocket extends Thread {
	
	OutputStream os;
	private boolean hiloActivo;

	public TecladoSocket(OutputStream os) {
		super();
		this.os = os;
		this.hiloActivo = true;
	}

	@Override
	public void run() {

		Scanner teclado = new Scanner(System.in);
		DataOutputStream socketOutput = new DataOutputStream(os);
		String leido = null;
		
		while(hiloActivo){
			leido = teclado.nextLine();
			try {
				socketOutput.writeUTF(leido);
			} catch (IOException e) {
				System.err.println("Error escribiendo en el socket");
				e.printStackTrace();
			}
		}
		
		
	}
	
	public void finalizarHilo(){
		hiloActivo = false;
	}
	

}
