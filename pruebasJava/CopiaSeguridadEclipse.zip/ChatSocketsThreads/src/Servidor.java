import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Servidor {

	/**
	 * @param args
	 */
	
	static public int PUERTO = 4321;
	
	public static void main(String[] args) {
		ServerSocket servidor= null;
		try {
			servidor =  new ServerSocket(PUERTO);
		} catch (IOException e) {
			System.err.println("Error abriendo el socket de Servidor");
			e.printStackTrace();
		}
		Socket socket = null;
		try {
			socket = servidor.accept();
		} catch (IOException e) {
			System.err.println("Error aceptando al comunicación entrante");
			e.printStackTrace();
		}
		try {
			servidor.close();
		} catch (IOException e) {
			System.err.println("Error cerrando el socket de servidor");
			e.printStackTrace();
		}
		System.out.println("Servidor: Conectado con "+socket.getInetAddress());
		
		TecladoSocket hiloEnvio = null;
		try {
			hiloEnvio = new TecladoSocket(socket.getOutputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		SocketPantalla hiloRecepcion = null;
		try {
			hiloRecepcion = new SocketPantalla(socket.getInputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		hiloEnvio.start();
		hiloRecepcion.start();
		
		try {
			Thread.sleep(100000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		hiloEnvio.finalizarHilo();
		hiloRecepcion.finalizarHilo();
		
		try {
			socket.close();
		} catch (IOException e) {
			System.err.println("Error cerrando el socket");
			e.printStackTrace();
		}
	}
}
