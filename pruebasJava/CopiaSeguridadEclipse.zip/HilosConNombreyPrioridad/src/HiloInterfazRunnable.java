
public class HiloInterfazRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println("Hola soy un hilo");

	}

}
