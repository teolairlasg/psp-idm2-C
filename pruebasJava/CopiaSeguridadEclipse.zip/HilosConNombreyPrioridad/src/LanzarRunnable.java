
public class LanzarRunnable {

	public static void main(String[] args) throws InterruptedException {

			HiloSegundero hs = new HiloSegundero();
			Thread hilo = new Thread(hs);
			hilo.start();
			Thread.sleep(5000);
			hilo.interrupt();
			
	}
	
}
